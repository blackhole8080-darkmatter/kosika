class AnswerCache:
    def __init__(self):
        self.values = {}

    def answer(self, project, model, prompt, generate):
        key = prompt
        if key not in self.values:
            self.values[key] = generate()
        return self.values[key]
