def save(adapter, key, value):
    return adapter.put(key, value)


def load(adapter, key):
    return adapter.get(key)
