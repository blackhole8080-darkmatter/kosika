from __future__ import annotations

import argparse
import ast
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("root", type=Path)
parser.add_argument("program", type=Path)
parser.add_argument("cases", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--model", default="qwen2.5:7b")
parser.add_argument("--url")
parser.add_argument("--protocol", choices=("openai", "ollama"), default="ollama")
args = parser.parse_args()
cases = json.loads(args.cases.read_text(encoding="utf-8"))
args.output.mkdir(parents=True, exist_ok=True)
records = []
for case in cases:
    name = case["id"]
    inputs = args.output / f"{name}-input.json"
    inputs.write_text(json.dumps({"request": case["request"]}), encoding="utf-8")
    trace = args.output / f"{name}.jsonl"
    sources = {
        field: hashlib.sha256((args.root / case["request"][field]).read_bytes()).hexdigest()
        for field in ("focus", "reference")
    }
    command = [
        sys.executable, "-m", "kosika.cli", "run", str(args.program),
        "--input", str(inputs), "--allow-folder", str(args.root),
        "--memory", str(args.output / f"{name}-memory"),
        "--model", args.model,
        "--model-protocol", args.protocol, "--model-timeout", "150", "--trace", str(trace),
    ]
    if args.url:
        command.extend(["--model-url", args.url])
    started = time.monotonic()
    try:
        process = subprocess.run(command, cwd=args.root, capture_output=True, text=True, timeout=690)
        record = {
            "id": name, "request": case["request"], "rubric": case["rubric"],
            "models": args.model,
            "source_sha256": sources, "exit_code": process.returncode,
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "stderr": process.stderr, "result": None, "execution": None,
        }
        for line in process.stdout.splitlines():
            if line.startswith("{"):
                try:
                    record["result"] = ast.literal_eval(line)
                    break
                except (SyntaxError, ValueError):
                    pass
        if trace.is_file():
            events = [json.loads(line) for line in trace.read_text(encoding="utf-8").splitlines()]
            if events and events[-1].get("event") == "run_complete":
                record["execution"] = events[-1].get("execution")
        if record["result"] is None:
            record["stdout"] = process.stdout[-5000:]
    except subprocess.TimeoutExpired as error:
        record = {
            "id": name, "request": case["request"], "rubric": case["rubric"],
            "models": args.model,
            "source_sha256": sources, "exit_code": None,
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "error": str(error), "result": None, "execution": None,
        }
    records.append(record)
    (args.output / "results.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    result = record.get("result") or {}
    print(json.dumps({
        "id": name, "exit": record["exit_code"], "seconds": record["elapsed_seconds"],
        "status": result.get("status"), "answer": result.get("answer"),
        "suggestions": result.get("suggestions"), "concerns": result.get("concerns"),
    }), flush=True)
